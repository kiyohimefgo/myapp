package com.example.giaodienthongtin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.text.Layout;
import android.widget.Toolbar;

import com.google.android.material.tabs.TabItem;

public class MainActivity extends AppCompatActivity {

    Toolbar mToolbar;
    Layout mTablayout;
    TabItem mThongtin;
    TabItem mChuong;
    ViewPager mPager;
    PagerController mPagerController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mToolbar = findViewById(R.id.toolBar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Truyện");

        mTablayout = findViewById(R.id.tabLayout);
        mThongtin = findViewById(R.id.thongtin);
        mChuong = findViewById(R.id.chuong);
        mPager = findViewById(R.id.viewPager);

        mPagerController = new PagerController(getSupportFragmentManager(),mTablayout.getTab);
    }

}
